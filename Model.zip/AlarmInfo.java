package com.example.sportapp.Model;

public class AlarmInfo {
    private String tooUid;

    public AlarmInfo() {
    }

    public String getTooUid() {
        return this.tooUid;
    }

    public void setTooUid(String Uid) {
        this.tooUid = tooUid;
    }
}
