package com.example.sportapp.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sportapp.R;

import java.util.ArrayList;

public class MyPageAdapter extends RecyclerView.Adapter<MyPageAdapter.MyViewHolder>{

    private ArrayList<String> talent;

    public MyPageAdapter(ArrayList<String> talent){
        this.talent = talent;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        String text = talent.get(position);
        holder.textView.setText("#" + text);
    }

    @Override
    public int getItemCount() {

        return (talent == null) ? 0 : talent.size();
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_talent_show,parent,false);
        return new MyViewHolder(view);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        public TextView textView;

        MyViewHolder(View view){
            super(view);
            textView = (TextView)view.findViewById(R.id.itemTalentTextView);
        }
    }
}
