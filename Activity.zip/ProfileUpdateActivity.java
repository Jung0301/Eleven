package com.example.sportapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sportapp.Adapter.MyPageAdapter;
import com.example.sportapp.Model.AlarmInfo;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;


public class ProfileUpdateActivity extends BasicActivity {
    private static final String TAG = "ProfileUpdateAcitvity";
    private static final int SEARCH_TALENT_ACTIVITY = 20000;


    private EditText profileUpdateNameEditText, profileUpdatePhoneEditText, profileUpdateBirthdayEditText;
    private ImageView profileUpdateImage;
    private RadioGroup profileUpdateRadioGroup;
    private RadioButton profileUpdateManRadioButton, profileUpdateWomanRadioButton;
    private RecyclerView profileUpdateLearnRecyclerView;
    private String name, phoneNumber, sex, birthDay;
    private String sex1 = "여자";
    private String sex2 = "남자";




    private ArrayList<String> profileUpdateTalents = new ArrayList<>();

    private HashMap<String, ArrayList<String>> profileUpdateTalentsHashMap = new HashMap<>();

    //재능을 바꾸면 알림 설정 초기화 및 상대 유저 알림에서도 초기화
    private ArrayList<String> TalentsUpdateLearnBefore = new ArrayList<>();
    private ArrayList<String> TalentsUpdateLearnAfter = new ArrayList<>();


    private FirebaseUser firebaseUser;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_update);

        profileUpdateNameEditText = (EditText) findViewById(R.id.profileUpdateNameEditText);
        profileUpdatePhoneEditText = (EditText) findViewById(R.id.profileUpdatePhoneEditText);
        profileUpdateBirthdayEditText = (EditText) findViewById(R.id.profileUpdateBirthdayEditText);

        profileUpdateImage = (ImageView) findViewById(R.id.profileUpdateImage);

        profileUpdateRadioGroup = (RadioGroup) findViewById(R.id.profileUpdateRadioGroup);

        profileUpdateManRadioButton = (RadioButton) findViewById(R.id.profileUpdateManRadioButton);
        profileUpdateWomanRadioButton = (RadioButton) findViewById(R.id.profileUpdateWomanRadioButton);

        profileUpdateLearnRecyclerView = (RecyclerView) findViewById(R.id.profileUpdateKindRecyclerView);

        findViewById(R.id.profileUpdateTalentSelectGotoButton).setOnClickListener(onClickListener);
        findViewById(R.id.UpdateButton).setOnClickListener(onClickListener);

        db = FirebaseFirestore.getInstance();
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();

        final DocumentReference docRef = db.collection("users").document(firebaseUser.getUid());

        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document != null) {
                        if (document.exists()) {

                            profileUpdateNameEditText.setText(document.getData().get("name").toString());
                            profileUpdatePhoneEditText.setText(document.getData().get("phoneNumber").toString());
                            profileUpdateBirthdayEditText.setText(document.getData().get("birthDay").toString());

                            if (document.getData().get("sex").toString().equals(sex1)) {
                                profileUpdateImage.setImageResource(R.drawable.woman);
                                profileUpdateWomanRadioButton.setChecked(true);

                            } else if (document.getData().get("sex").toString().equals(sex2)) {
                                profileUpdateImage.setImageResource(R.drawable.man);
                                profileUpdateManRadioButton.setChecked(true);
                            } else {

                            }


                            profileUpdateTalents = (ArrayList<String>) document.getData().get("learnTalent");
                            profileUpdateTalentsHashMap = (HashMap<String, ArrayList<String>>) document.getData().get("learnTalentHashMap");
                            TalentsUpdateLearnBefore = profileUpdateTalents;
                            profileUpdateLearnRecyclerView.setLayoutManager(new LinearLayoutManager(ProfileUpdateActivity.this, LinearLayoutManager.HORIZONTAL, true));
                            profileUpdateLearnRecyclerView.setAdapter(new MyPageAdapter(profileUpdateTalents));


                        } else {
                            Log.d(TAG, "No such document");
                        }
                    }
                } else {
                    Log.d(TAG, "get failed with ", task.getException());
                }
            }
        });

        profileUpdateRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int chechedId) {
                RadioButton select;
                if (chechedId == R.id.profileUpdateManRadioButton) {
                    profileUpdateImage.setImageResource(R.drawable.man);
                    select = (RadioButton) findViewById(chechedId);
                    sex = select.getText().toString();
                } else if (chechedId == R.id.profileUpdateWomanRadioButton) {
                    profileUpdateImage.setImageResource(R.drawable.woman);
                    select = (RadioButton) findViewById(chechedId);
                    sex = select.getText().toString();
                } else {
                    startToast("성별을 체크해주세요.");
                }
            }
        });
    }

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @SuppressLint("ResourceAsColor")
        @Override
        public void onClick(View v) {
            switch (v.getId()) {

                case R.id.profileUpdateTalentSelectGotoButton:
                    myStartActivity(TalentSelectActivity.class, SEARCH_TALENT_ACTIVITY);
                    break;
                case R.id.UpdateButton:
                    profileUpdate();
                    break;
            }
        }
    };

    private void myStartActivity(Class c, int go) {
        Intent intent = new Intent(this, c);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivityForResult(intent, go);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {

            case SEARCH_TALENT_ACTIVITY:
                if (resultCode == RESULT_OK) {
                    profileUpdateTalents = data.getStringArrayListExtra("learn");


                    profileUpdateTalentsHashMap = (HashMap<String, ArrayList<String>>) data.getSerializableExtra("learnMap");


                    TalentsUpdateLearnAfter = profileUpdateTalents;


                    profileUpdateLearnRecyclerView.setLayoutManager(new LinearLayoutManager(ProfileUpdateActivity.this, LinearLayoutManager.HORIZONTAL, true));


                    profileUpdateLearnRecyclerView.setAdapter(new MyPageAdapter(profileUpdateTalents));

                }
                break;
        }
    }

    private void profileUpdate() {
        name = profileUpdateNameEditText.getText().toString();
        phoneNumber = profileUpdatePhoneEditText.getText().toString();
        birthDay = profileUpdateBirthdayEditText.getText().toString();


        if (name.length() > 0 && phoneNumber.length() > 9 && birthDay.length() > 5 && sex.length() > 0 ) {
            db = FirebaseFirestore.getInstance();
            firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
           /*
            /Memberinfo memberinfo = new Memberinfo(name, phoneNumber, birthDay, sex, profileUpdateTalents, profileUpdateTalentsHashMap);
            if(firebaseUser != null){
                db.collection("users").document(firebaseUser.getUid()).set(memberinfo)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                startToast("회원정보 수정을 성공하였습니다.");
                                myStartActivity(MypageActivity.class, 0);
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                startToast("회원정보 수정을 실패하였습니다.");
                                Log.w(TAG, "Error writing document", e);
                            }
                        });
            }
            Intent intentMyPage = new Intent(ProfileUpdateActivity.this, MypageActivity.class);
            intentMyPage.putExtra("loading", 1);
            startActivity(intentMyPage);
            */

            if (TalentsUpdateLearnBefore != TalentsUpdateLearnAfter) {
                AlarmInfo memberinfoAlarm = new AlarmInfo();
                updateAlarm(memberinfoAlarm);
            }
            update();


        } else {
            startToast("회원정보를 모두 입력해주세요.");
        }
    }

    private void update() {
        db = FirebaseFirestore.getInstance();

        Memberinfo memberinfo = new Memberinfo(name, phoneNumber, birthDay, sex, profileUpdateTalents);
        db.collection("users").document(firebaseUser.getUid()).set(memberinfo)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        startToast("회원정보 수정을 성공하였습니다.");
                        myStartActivity(MypageActivity.class, 0);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        startToast("회원정보 수정을 실패하였습니다.");
                        Log.w(TAG, "Error writing document", e);
                    }
                });

    }

    private void updateAlarm(AlarmInfo memberinfoAlarm) {
        db = FirebaseFirestore.getInstance();
        db.collection("alarm").document(firebaseUser.getUid()).set(memberinfoAlarm)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error writing document", e);
                    }
                });

        db.collection("alarm")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                if (document.getData().get(firebaseUser.getUid()) != null)
                                    document.getReference().update(firebaseUser.getUid(), 0);
                            }
                        } else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                        }
                    }
                });

    }

    private void startToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}