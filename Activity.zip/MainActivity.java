package com.example.sportapp;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.drawerlayout.widget.DrawerLayout;
import com.example.sportapp.StartActivity;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;
import com.example.sportapp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Calendar;
import java.util.zip.CheckedInputStream;

public class MainActivity extends AppCompatActivity {

    private ImageView drawerOpenImageView;
    private TextView chattingGoImageView,myPageGoImageView,homeGoImageView,circleImageView;
    private DrawerLayout drawerLayout;
    private View drawerView;
    private ListView chat_list;

    DatePicker datePicker;  //  datePicker - 날짜를 선택하는 달력
    TextView viewDatePick;  //  viewDatePick - 선택한 날짜를 보여주는 textView
    EditText edtDiary;   //  edtDiary - 선택한 날짜의 일기를 쓰거나 기존에 저장된 일기가 있다면 보여주고 수정하는 영역
    Button btnRegister;   //  btnSave - 선택한 날짜의 일기 저장 및 수정(덮어쓰기) 버튼
    Button btnRating, btncircle, btnmypage;

    String fileName;   //  fileName - 돌고 도는 선택된 날짜의 파일 이름


    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference databaseReference = firebaseDatabase.getReference();

    @Override
    protected void onCreate(Bundle savedInstanceState) { // 앱 첫 시작 시 돌아가는 메소드
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("스포츠 매칭 시스템");




        // 뷰에 있는 위젯들 리턴 받아두기
        datePicker = (DatePicker) findViewById(R.id.datePicker);
        viewDatePick = (TextView) findViewById(R.id.viewDatePick);

        btnRegister = (Button) findViewById(R.id.register);
        chat_list = (ListView)findViewById(R.id.chat_list);
        drawerOpenImageView = findViewById(R.id.drawerOpenImageView);
        drawerLayout = (DrawerLayout)findViewById(R.id.drawer);
        drawerView = (View)findViewById(R.id.drawer_activity);
        drawerOpenImageView.setOnClickListener(onClickListener);
        circleImageView = findViewById(R.id.circleImageView);
        myPageGoImageView = findViewById(R.id.myPageGoImageView);

        findViewById(R.id.logoutButton).setOnClickListener(onClickListener);
        circleImageView.setOnClickListener(onClickListener);
        myPageGoImageView.setOnClickListener(onClickListener);


        // 오늘 날짜를 받게해주는 Calender 친구들
        Calendar c = Calendar.getInstance();
        int cYear = c.get(Calendar.YEAR);
        int cMonth = c.get(Calendar.MONTH);
        int cDay = c.get(Calendar.DAY_OF_MONTH);

        // 첫 시작 시에는 오늘 날짜 일기 읽어주기
        checkedDay(cYear, cMonth, cDay);


        // 저장/수정 버튼 누르면 실행되는 리스너
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intentList = new Intent(MainActivity.this, StartActivity.class);
                intentList.putExtra("loading", 1);
                startActivity(intentList);
            }
        });

        showChatList();
    }

    private void checkedDay(int year, int monthOfYear, int dayOfMonth) {

        // 받은 날짜로 날짜 보여주는
        viewDatePick.setText(year + " - " + (monthOfYear+1) + " - " + dayOfMonth); /// 등록 위 빈칸 날짜 채우기

        // 파일 이름을 만들어준다. 파일 이름은 "20170318.txt" 이런식으로 나옴
        fileName = year + "" + monthOfYear + "" + dayOfMonth + ".txt";



    }




    private void showChatList() {
        // 리스트 어댑터 생성 및 세팅
        final ArrayAdapter<String> adapter

                = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, android.R.id.text1);
        chat_list.setAdapter(adapter);

        // 데이터 받아오기 및 어댑터 데이터 추가 및 삭제 등..리스너 관리
        databaseReference.child("chat").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                Log.e("LOG", "dataSnapshot.getKey() : " + dataSnapshot.getKey());
                adapter.add(dataSnapshot.getKey());
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @SuppressLint("ResourceAsColor")
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.drawerOpenImageView:
                    drawerLayout.openDrawer(drawerView);
                    break;


                case R.id.circleImageView:
                    Intent intentCircle = new Intent(MainActivity.this, CircleActivity.class);
                    intentCircle.putExtra("loading", 1);
                    startActivity(intentCircle);
                    break;
                case R.id.logoutButton:
                    FirebaseAuth.getInstance().signOut();
                    Intent intentLogout = new Intent(MainActivity.this, LoginActivity.class);
                    intentLogout.putExtra("loading", 1);
                    startActivity(intentLogout);
                    break;
                case R.id.myPageGoImageView:
                    Intent intentMyPage = new Intent(MainActivity.this, MypageActivity.class);
                    intentMyPage.putExtra("loading", 1);
                    startActivity(intentMyPage);
                    break;

            }

        }
    };



}