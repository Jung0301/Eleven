package com.example.sportapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.CheckedTextView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sportapp.R;
import com.example.sportapp.MainActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import androidx.annotation.RequiresApi;

public class TalentSelectActivity extends MainActivity {
    private static final String TAG = "TalentSelectActivity";

    private ArrayList<String> item1 = new ArrayList<String>();


    private MySpinnerAdapter adapter1;

    private ArrayList<String> learnSubjects_exercise = new ArrayList<>();    //배울 재능 넣을 배열
    private ArrayList<String> learnSubjects = new ArrayList<>();
    private HashMap<String,ArrayList<String>> learnSubjectMap = new HashMap<>();


    private MyArrayAdapter adapter11;

    private List<MyItem> exercise = new ArrayList<>();



    private TextView learnTextView;
    private String nul = "없음";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_talent_select);

        learnTextView = findViewById(R.id.learnShowTextView); // 그냥 각각 확인용

        findViewById(R.id.talentSendButton).setOnClickListener(onClickListener);


        exercise.add(new MyItem("축구", false));
        exercise.add(new MyItem("풋살", false));
        exercise.add(new MyItem("헬스", false));
        exercise.add(new MyItem("농구", false));
        exercise.add(new MyItem("수영", false));
        exercise.add(new MyItem("당구", false));
        exercise.add(new MyItem("배드민턴", false));
        exercise.add(new MyItem("볼링", false));
        exercise.add(new MyItem("수영", false));
        exercise.add(new MyItem("탁구", false));
        exercise.add(new MyItem("테니스", false));

        //재능의 종류

        item1.add("운동");
        item1.add(" ");
        item1.add(" ");
        item1.add(" ");
        item1.add(" ");
        item1.add(" ");
        item1.add(" ");
        item1.add(" ");
        item1.add(" ");
        item1.add(" ");
        item1.add(" ");

        final ListView learnListView = (ListView) findViewById(R.id.learnListView);

        learnListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);


        adapter1 = new MySpinnerAdapter(this, android.R.layout.simple_spinner_item, item1);

        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);



        adapter11 = new MyArrayAdapter(exercise);

        learnListView.setAdapter(adapter11);
        learnListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.N)
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        String selectedItem = ((TextView) view).getText().toString();

                        if (learnSubjects_exercise.contains(selectedItem)) {
                            if(learnSubjects_exercise.contains(selectedItem)){
                                learnSubjects_exercise.remove(selectedItem);
                            }
                            learnSubjects.remove(selectedItem);
                            learnTextView.setText(learnSubjects.toString());
                        } else {
                            if(selectedItem == "축구" || selectedItem == "헬스" || selectedItem == "농구"|| selectedItem == "수영"){
                                learnSubjects_exercise.add(selectedItem);
                            }
                            learnSubjects.add(selectedItem);
                            learnTextView.setText(learnSubjects.toString());
                        }

                        CheckedTextView tv1 = (CheckedTextView) view;
                        if (item1.get(position).equals("운동")) {
                            exercise.get(position).checked = tv1.isChecked();
                        }
                    }
                });

                for (int i = 0; i < learnListView.getAdapter().getCount(); i++) {
                    learnListView.setItemChecked(i, learnSubjects.contains(((MyItem) learnListView.getAdapter().getItem(i)).name));
                }

            }





    //문제가 있음 바로 talent액티비티가 안꺼짐
    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.talentSendButton:
                    MapAdd();
                    Intent intent = new Intent();
                    intent.putExtra("learn", learnSubjects);
                    intent.putExtra("learnMap",learnSubjectMap);
                    setResult(RESULT_OK, intent);
                    finish();
                    break;
            }
        }
    };


    //스피너 힌트 만들기
    public class MySpinnerAdapter extends ArrayAdapter<String> {

        public MySpinnerAdapter(Context context, int resource, List<String> objects) {
            super(context, resource, objects);
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            View v = super.getView(position, convertView, parent);
            if (position == getCount()) {
                ((TextView) v.findViewById(android.R.id.text1)).setText("");
                ((TextView) v.findViewById(android.R.id.text1)).setHint(getItem(getCount()));
            }
            return v;
        }

        public int getCount() {
            return super.getCount() - 1;
        }

    }

    private void startToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }


    public class MyArrayAdapter extends BaseAdapter {
        private List<MyItem> mList = null;

        public MyArrayAdapter(List<MyItem> list) {
            mList = list;
        }

        @Override
        public int getCount() {
            return mList.size();
        }

        @Override
        public MyItem getItem(int i) {
            return mList.get(i);
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            @SuppressLint("ViewHolder") View v = LayoutInflater.from(getApplicationContext()).inflate(R.layout.simple_list_item, null);
            CheckedTextView tv = v.findViewById(android.R.id.text1);
            tv.setText(getItem(i).name);
            return v;
        }
    }

    class MyItem {
        public MyItem(String name, boolean checked) {
            this.name = name;
            this.checked = checked;
        }

        String name;
        boolean checked = false;
    }
    private void MapAdd(){
        learnSubjectMap.put("운동",learnSubjects_exercise);
    }
}