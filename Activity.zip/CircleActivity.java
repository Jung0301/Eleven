package com.example.sportapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.BaseAdapter;



import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.sportapp.Adapter.MyAdapter;

import java.util.ArrayList;
import java.util.List;

public class CircleActivity extends AppCompatActivity {

    private ListView list;
    String mTitle[]={"일레븐","디파이","블레스","펜타곤","대쉬","볼링","당구","테니스","탁구"};//listview에 title부분 설정
    String mDescription[]={"kakotalk_id : eleven","kakotalk_id : defy ","kakotalk_id : bless","kakotalk_id : pentagon","kakotalk_id : dash","kakotalk_id : bowling","kakotalk_id : billiadrs","kakotalk_id : tennis","kakotalk_id : table tennis"};//listview에 설명부분
    int images[]={R.drawable.soccer,R.drawable.soccer,R.drawable.soccer,R.drawable.basketball,R.drawable.basketball,R.drawable.bowling,R.drawable.billiards,R.drawable.tennis,R.drawable.tabletennis};
    //listview에 들어가는 사진

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_circle);
        setTitle("동아리 목록");

        list=(ListView)findViewById(R.id.list);

        MyAdapter adapter=new MyAdapter(this,mTitle,mDescription,images);
        list.setAdapter(adapter);//리스트에 어뎁터 설정
        Intent intent=new Intent(this.getIntent());
    }

}