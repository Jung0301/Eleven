package com.example.sportapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.sportapp.Adapter.MyPageAdapter;
import com.example.sportapp.BasicActivity;
import com.example.sportapp.MainActivity;
import com.example.sportapp.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;

//import com.example.hangoutwithus_project.Adapter.MyPageAdapter;

public class MypageActivity extends BasicActivity {
    private static final String TAG = "MypageActivity";

    private ImageView myPageProfileImageView;
    private TextView tv_name, tv_address, tv_number,chattingGoImageView,homeGoImageView;
    private String sex1 = "여자";
    private String sex2 = "남자";
    private FirebaseUser firebaseUser;
    private FirebaseFirestore db;
    private RecyclerView learnMypageRecyclerView, teachMypageRecyclerView;
    private ArrayList<String> myPageLearnTalent = new ArrayList<>();


    private int a;  //매칭수정버튼

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mypage);

        myPageProfileImageView = (ImageView) findViewById(R.id.myPageProfileImageView);
        tv_name = (TextView) findViewById(R.id.tv_name);
        tv_number = (TextView) findViewById(R.id.tv_number);
        chattingGoImageView = findViewById(R.id.chattingGoImageView);
        homeGoImageView = findViewById(R.id.homeGoImageView);

        findViewById(R.id.profileUpdateButton).setOnClickListener(onClickListener);
        chattingGoImageView.setOnClickListener(onClickListener);
        homeGoImageView.setOnClickListener(onClickListener);
        findViewById(R.id.logoutButton).setOnClickListener(onClickListener);

        learnMypageRecyclerView = (RecyclerView) findViewById(R.id.MypageRecyclerView);



        db = FirebaseFirestore.getInstance();
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();

        final DocumentReference docRef = db.collection("users").document(firebaseUser.getUid());
        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document != null) {
                        if (document.exists()) {
                            Log.d(TAG,
                                    "DocumentSnapshot data: " + document.getData());
                            int setting = Integer.parseInt(document.getData().get("settingCheck").toString());
                            if (setting == 0) {
                                a = 0;
                            } else {
                                a = 1;
                            }

                            tv_name.setText(document.getData().get("name").toString());
                            tv_number.setText(document.getData().get("phoneNumber").toString());
                            if (document.getData().get("sex").toString().equals(sex1)) {
                                myPageProfileImageView.setImageResource(R.drawable.woman);
                            } else if (document.getData().get("sex").toString().equals(sex2)) {
                                myPageProfileImageView.setImageResource(R.drawable.man);
                            }
                            myPageLearnTalent = (ArrayList<String>) document.getData().get("talent");

                            learnMypageRecyclerView.setLayoutManager(new LinearLayoutManager(MypageActivity.this, LinearLayoutManager.HORIZONTAL, true));
                            learnMypageRecyclerView.setAdapter(new MyPageAdapter(myPageLearnTalent));

                        } else {
                            Log.d(TAG, "No such document");
                        }
                    }
                } else {
                    Log.d(TAG, "get failed with ", task.getException());
                }
            }
        });
    }

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @SuppressLint("ResourceAsColor")
        @Override
        public void onClick(View v) {
            switch (v.getId()) {

                case R.id.profileUpdateButton:
                    myStartActivity(ProfileUpdateActivity.class,0);
                    break;





                case R.id.homeGoImageView:
                    myStartActivity(MainActivity.class, 0);
                    break;
                case R.id.logoutButton:
                    FirebaseAuth.getInstance().signOut();
                    Intent intentLogout = new Intent(MypageActivity.this, LoginActivity.class);
                    intentLogout.putExtra("loading", 1);
                    startActivity(intentLogout);
                    break;
            }
        }
    };

    private void myStartActivity(Class c, int go) {
        Intent intent = new Intent(this, c);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivityForResult(intent, go);
    }

    private void startToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}