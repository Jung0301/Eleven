package com.example.sportapp;

import androidx.room.Entity;
import androidx.room.PrimaryKey;


import java.util.ArrayList;
import java.util.HashMap;


public class Memberinfo {

    private String name;
    private String phoneNumber;
    private String birthDay;
    private String sex;
    private ArrayList<String> Talent;
    private HashMap<String,ArrayList<String>> TalentHashMap;
    private int settingCheck;   //setting을 했는지 안했는지 판단
    private String uid;
    private String pushToken;

    public Memberinfo(){}


    public Memberinfo(String name, String phoneNumber, String birthDay, String sex ) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.birthDay = birthDay;
        this.sex = sex;



    }
    public Memberinfo(String name, String phoneNumber, String birthDay, String sex, ArrayList<String> talent) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.birthDay = birthDay;
        this.sex = sex;
        this.Talent = talent;


    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(String birthDay) {
        this.birthDay = birthDay;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public ArrayList<String> getTalent() {
        return Talent;
    }

    public void setTalent(ArrayList<String> talent) {
        Talent = talent;
    }

    public HashMap<String, ArrayList<String>> getTalentHashMap() {
        return TalentHashMap;
    }

    public void setTalentHashMap(HashMap<String, ArrayList<String>> talentHashMap) {
        TalentHashMap = talentHashMap;
    }

    public int getSettingCheck() {
        return settingCheck;
    }

    public void setSettingCheck(int settingCheck) {
        this.settingCheck = settingCheck;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getPushToken() {
        return pushToken;
    }

    public void setPushToken(String pushToken) {
        this.pushToken = pushToken;
    }
}

